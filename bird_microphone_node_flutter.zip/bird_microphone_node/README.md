# Bird Microphone Node

This Flutter Android application continuously captures microphone audio and streams
raw 16-bit PCM audio to the bird-localization laptop server using WebSocket.

## 1. Install Flutter

Install Flutter from the official Flutter documentation and ensure that:

```bash
flutter --version
```

works in your terminal.

Then run:

```bash
flutter doctor
```

Fix any Android-related issues shown by Flutter Doctor.

## 2. Create missing Flutter platform files

This ZIP contains the project source files. If you have not generated the full Flutter
project structure yet, open a terminal in this folder and run:

```bash
flutter create .
```

Then restore the files from this project if Flutter asks to overwrite them.

## 3. Install dependencies

```bash
flutter pub get
```

## 4. Run on a connected Android phone

Enable Developer Options and USB Debugging on the phone.

Connect the phone using USB and run:

```bash
flutter devices
flutter run
```

## 5. Build an APK

For a release APK:

```bash
flutter build apk --release
```

The generated APK will normally be located at:

```text
build/app/outputs/flutter-apk/app-release.apk
```

Copy that APK to the other Android phones and install it.

## 6. Configure the three phones

Use these IDs:

- Phone 1: `phone_1`
- Phone 2: `phone_2`
- Phone 3: `phone_3`

Find the laptop's Wi-Fi IPv4 address using:

### Windows

```bash
ipconfig
```

Example:

```text
192.168.1.100
```

Then enter this on every phone:

```text
ws://192.168.1.100:8000/ws
```

All phones and the laptop must be on the same Wi-Fi network.

## Important

The laptop FastAPI server must be running before you press START RECORDING.

The server currently expects 44,100 Hz mono PCM16 audio.
